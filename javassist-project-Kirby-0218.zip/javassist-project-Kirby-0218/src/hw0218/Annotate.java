package hw0218;

import java.lang.reflect.Proxy;
import java.util.Iterator;
import java.util.Scanner;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationImpl;
import javassist.bytecode.annotation.MemberValue;

public class Annotate {
	static String className;
	static String anno1;
	static String anno2;

	public static void main(String[] args0) {
		Scanner sc = new Scanner(System.in);
		String[] list;
		boolean quit = false;

		do {
			System.out.println(
					"Please enter a class name, first annotation name, and second annotation name--separated by commas.\n"
							+ "(e.g. ComponentApp, Column, Author or ServiceApp, Row, Author)\n"
							+ "Key \\\"q\\\" to quit.");
			String input = sc.nextLine();
			list = input.split(",");
			for (int i = 0; i < list.length; i++) {
				list[i] = list[i].trim();
				if (list[i].equals("q")) {
					System.out.println("You have quit the program.");
					sc.close();
					System.exit(0);
				}
			}
			System.out.println("");

			if (list.length != 3) {
				System.out.println("[WRN] Invalid Input size!!\n");
				for (int i = 0; i < list.length; i++) {
					list[i] = null;
				}
			} else {
				className = "target." + list[0];
				anno1 = "target." + list[1];
				anno2 = "target." + list[2];

				try {
					ClassPool pool = ClassPool.getDefault();
					CtClass ct = pool.get(className);
					CtField[] fields = ct.getFields();
					for (int i = 0; i < fields.length; i++) {
						Object[] annoList = fields[i].getAnnotations();
						process(annoList, anno1, anno2);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			System.out.println("---------------------------------------------------------------");
		} while (!quit);
	}

	static void process(Object[] annoList, String anno1, String anno2) {
		for (int i = 0; i < annoList.length; i++) {
			Annotation annotation = getAnnotation(annoList[i]);
			if (annotation.getTypeName().contentEquals(anno1)) {
				process2(annoList, anno1, anno2);
			}
		}
	}

	static void process2(Object[] annoList, String anno1, String anno2) {
		for (int i = 0; i < annoList.length; i++) {
			Annotation annotation = getAnnotation(annoList[i]);
			if (annotation.getTypeName().contentEquals(anno2)) {
				showAnnotation(annotation);
			}
		}
	}

	static Annotation getAnnotation(Object obj) {
		// Get the underlying type of a proxy object in java
		AnnotationImpl annotationImpl = //
				(AnnotationImpl) Proxy.getInvocationHandler(obj);
		return annotationImpl.getAnnotation();
	}

	static void showAnnotation(Annotation annotation) {
		Iterator<?> iterator = annotation.getMemberNames().iterator();
		while (iterator.hasNext()) {
			Object keyObj = (Object) iterator.next();
			MemberValue value = annotation.getMemberValue(keyObj.toString());
			System.out.print(keyObj + ": " + value);

			if (iterator.hasNext()) {
				System.out.print(", ");
			} else {
				System.out.println();
			}
		}
	}
}